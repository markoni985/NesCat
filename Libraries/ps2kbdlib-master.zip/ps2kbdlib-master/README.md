# ps2kbdlib
PS2 keyboard library for ESP32 or Arduino.

Warning: Does not currently support keyboard LEDs, Prt scr.
