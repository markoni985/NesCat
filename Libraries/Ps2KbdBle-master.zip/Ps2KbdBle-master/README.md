# Ps2KbdBle
Esp32 code for converting an old clicky IBM keyboard into a BLE input device
